# __init__.py
from .sparse_pixel_map import SparsePixelMap

