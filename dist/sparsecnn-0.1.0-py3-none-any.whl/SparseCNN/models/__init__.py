# __init__.py
from .fishnet import LightningFish

